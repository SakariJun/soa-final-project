1. Tất cả hình ảnh sử dụng trong báo cáo được đặt tại thư mục pics.
2. Báo cáo được trình bày dưới các phần chia nhỏ như: 
- intro.tex: trình bày lời cảm ơn, phần đánh giá của giảng viên, cam kết thực hiện đồ án,...
- main.tex: chứa bố cục, cấu trúc trình bày tổng quát của báo cáo.
- part1.tex: chứa chương 1 của báo cáo.
- part2.tex: chương 2,3,4,5 của báo cáo.
- phancong.tex: bảng phân công và đánh giá làm việc của các thành viên.