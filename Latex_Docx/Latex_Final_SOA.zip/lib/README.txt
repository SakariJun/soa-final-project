1. TDTlogo.jpg: hình ảnh logo trường Đại học Tôn Đức Thắng.
2. lib.sty: gói thư viện đã add vào file tex,\
Margin: left=3.5cm, right=2cm, top=3.5cm, bottom= 3cm.
