const _Absence = require('./absence.model');
const _AbsenceRequest = require('./absence-request.model');

module.exports = {
    _Absence,
    _AbsenceRequest,
};
