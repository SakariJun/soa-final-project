const _Department = require('./department.model');

module.exports = {
    _Department,
};
