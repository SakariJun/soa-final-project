module.exports = {
    createDepartmentValidator: require('./create-department.validator'),
};
