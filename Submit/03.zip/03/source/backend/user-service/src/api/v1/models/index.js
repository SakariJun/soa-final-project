const _User = require('./user.model');
const _Role = require('./role.model');

module.exports = {
    _Role,
    _User,
};
