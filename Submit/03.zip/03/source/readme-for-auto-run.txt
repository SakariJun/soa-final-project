1. Mở file python-venv-name.txt
2. Ghi vào tên môi trường ảo muốn sử dụng
3. chạy file run.bat

LƯU Ý:
- Môi trường ảo python phải đã tồn tại ( đã tạo ) nếu không sẽ lỗi.
- Project sử dụng virtualenvwrapper, lệnh để activate môi trường là "workon <venv-name>".
- Nếu sử dụng package khác ( lệnh khác ) -> Vui lòng edit file run.bat ( dòng 4 - bắt đầu từ kí tự 55 )