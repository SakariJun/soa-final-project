# Grocery_Online_Shopping_App
This is a practical example of NodeJS Microservices Architecture. We have built a simple Online Grocery Shopping Application using ES6 in a Monolithic way and segregate in Microservices Architecture without impact frontend. So each individual services will work independently to server the purpose and business logic.  You can watch it's Youtube tutorial for better understanding and for Microservice you can code along with me.

## Microservice version link:

[Grocery Online Shopping App Microservice](https://github.com/codergogoi/nodejs_microservice)
