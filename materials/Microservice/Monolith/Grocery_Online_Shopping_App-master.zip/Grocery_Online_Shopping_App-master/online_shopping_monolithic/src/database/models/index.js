module.exports = {
    CustomerModel: require('./Customer'),
    ProductModel: require('./Product'),
    OrderModel: require('./Order'),
    AddressModel: require('./Address')
}